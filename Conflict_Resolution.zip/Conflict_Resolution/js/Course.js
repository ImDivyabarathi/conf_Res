var eLearningCourse = function(courseConfigObj){
	var _this = this;
	
	_this.isAudioPlaying = false;
	_this.isTranscriptShown = false;
	
	_this.courseDataPath = courseConfigObj.courseDataPath;
	_this.commonAudioPath = courseConfigObj.commonAudioPath;
	_this.commonPagePath = courseConfigObj.commonPagePath;
	_this.commonDataPath = courseConfigObj.commonDataPath;
	_this.audioIntervalID = "";
	_this.curTemplateObj = "";
	
	//_this.$courseContainer = courseConfigObj.$courseContainer;
	_this.$homeBtn = courseConfigObj.home.$homeBtn;
	_this.$startBtn = courseConfigObj.start.$startBtn;
	_this.$nextBtn = courseConfigObj.next.$nextBtn;
	_this.$prevBtn = courseConfigObj.previous.$prevBtn;
	_this.$playBtn = courseConfigObj.play.$playBtn;
	_this.$muteBtn = courseConfigObj.mute.$muteBtn;
	_this.$transcriptBtn = courseConfigObj.transcript.$transcriptBtn;
	_this.$transcriptCloseBtn = courseConfigObj.transcript.$transcriptCloseBtn;
	
	_this.$transcriptDragHandle = courseConfigObj.transcript.$transcriptDragHandle;
	_this.$transcriptContainer = courseConfigObj.transcript.$transcriptContainer;
	_this.$transcriptContent = courseConfigObj.transcript.$transcriptContent;
	
	_this.$startPageContainer = courseConfigObj.start.$startPageContainer;
	_this.$screenContainer = courseConfigObj.$screenContainer;
	_this.$contentContainer = courseConfigObj.$contentContainer;
	//_this.$individualPageContainer = courseConfigObj.$individualPageContainer;
	
	_this.muteClass = courseConfigObj.mute.muteClass;
	_this.unMuteClass = courseConfigObj.mute.unMuteClass;
	
	_this.playClass = courseConfigObj.play.playClass;
	_this.pauseClass = courseConfigObj.play.pauseClass;
	
	_this.curAudioName = '';
	
	_this.curScreenSpriteAnimation = '';
	
	_this.$hiddenText = courseConfigObj.$hiddenText;
	_this.$clickNext =  courseConfigObj.clickNext.$clickNext;
	_this.$preloader = courseConfigObj.preloader.$preloader;
	_this.imagesArr = courseConfigObj.preloader.imagesArr;
	_this.soundsArr = courseConfigObj.preloader.soundsArr;
	
	_this.blinkClass = courseConfigObj.blinkClass;
	_this.loadedImageCount = 0;	
	_this.curSoundJsInstance = '';
	_this.isScreenLoadCompleted = false;
	_this.blinkID = '';
	
	_this.isAudioMuted = false;
	
	this.init = function(){
		_this.$preloader.show();
		_this.$startPageContainer.hide();
		_this.$screenContainer.hide();
		_this.loadSounds();
		_this.preloadImages();
	}
	
	this.preloadImages = function(){
		for(var i=0;i<_this.imagesArr.length;i++){
			var imageObj = new Image();
			imageObj.src = _this.imagesArr[i];
			imageObj.addEventListener('load',_this.onImagePreload,false);
			imageObj.addEventListener('error',_this.onImagePreload,false);
		}
	}
	
	this.onImagePreload = function(){
		_this.loadedImageCount++;
		if(_this.loadedImageCount == _this.imagesArr.length-1){
			//_this.$courseContainer.fadeIn();
			_this.$startPageContainer.show();
			_this.$screenContainer.hide();
			_this.$transcriptContainer.hide();
			_this.$preloader.hide();
			
			//_this.createAudio();
			//_this.playAudio("Welcome");
			//_this.$transcriptDragHandle == '' ? _this.$transcriptContainer.draggable() : _this.$transcriptContainer.draggable({handle:_this.$transcriptDragHandle});
			//_this.$transcriptDragHandle == '' ? _this.enableTranscriptDrag();
			_this.loadCourseData();			
		}
	}
	
	this.loadSounds = function(){
		var sounds = _this.soundsArr;
		createjs.Sound.addEventListener("fileload", createjs.proxy(_this.onSoundLoad, this)); // add an event listener for when load is completed
		createjs.Sound.registerSounds(sounds, _this.commonAudioPath);	
	}
	
	this.onSoundLoad = function(){
		console.log('File load');		
	}	
	
	this.loadCourseData = function(){
		console.log("LOAD COURSE DATA");
		console.log(_this.courseDataPath);
		$.ajax({
			url:_this.courseDataPath+"?version="+(new Date()).getTime(),
			dataType : "json",
			success:_this.onCourseDataLoadSuccess
		});		
	}
	
	this.onCourseDataLoadSuccess = function(courseData){
		console.log("onCourseDataLoadSuccess");
		console.log(courseData);
		
		_this.courseData = courseData.data;
		_this.screenData = _this.courseData.screens;
		_this.curScreenNo = 1;
		_this.totalScreens = _this.screenData.length;
		
		_this.createAudio();
		_this.addEvents();
		_this.configCourseButtons();		
	}
	
	this.addEvents = function(){
		_this.$homeBtn.off('click').on('click',_this.onHomeBtnClick);
		_this.$startBtn.off('click').on('click',_this.onStartBtnClick);
		_this.$playBtn.off('click').on('click',_this.onPlayBtnClick);
		_this.$nextBtn.off('click').on('click',_this.onNextBtnClick);
		_this.$prevBtn.off('click').on('click',_this.onPrevBtnClick);
		_this.$muteBtn.off('click').on('click',_this.onMuteBtnClick);
		_this.$transcriptBtn.off('click').on('click',_this.onTranscriptBtnClick);
		_this.$transcriptCloseBtn.off('click').on('click',_this.onTranscriptCloseBtnClick);
	}
	
	this.configCourseButtons = function(){
		(courseConfigObj.transcript.isRequired == false) ? _this.$transcriptBtn.hide() : _this.$transcriptBtn.show() , _this.enableTranscriptDrag();
		(courseConfigObj.mute.isRequired == false) ? _this.$muteBtn.hide() : _this.$muteBtn.show();
		(courseConfigObj.play.isRequired == false) ? _this.$playBtn.hide() : _this.$playBtn.show();
		(courseConfigObj.home.isRequired == false) ? _this.$homeBtn.hide() : _this.$homeBtn.show();
	}
	
	this.onStartBtnClick = function(){
		_this.playAudio("blank");
		_this.$startPageContainer.hide();
		_this.$screenContainer.show();
		_this.loadScreen();
	}

	this.onHomeBtnClick = function(){
		_this.$startPageContainer.show();
		_this.$screenContainer.hide();	
		_this.curScreenNo = 1;
		_this.clearAudio();
		(_this.curTemplateObj != "") ? _this.curTemplateObj.clear() : "";
	}
	
	this.enableNextBlink = function(){
		_this.disableNextBlink();
		_this.startBlink();
	}
	
	this.startBlink = function(){
		_this.blinkID = setTimeout(function(){
			_this.$nextBtn.toggleClass(_this.blinkClass);	
			_this.startBlink();
		},600);
	}
	
	this.disableNextBlink = function(){
		clearTimeout(_this.blinkID);	
	}
	
	/**
		Transcript
	*/
		
	this.onTranscriptBtnClick = function(){
		console.log( _this.$transcriptContainer );
		if(!_this.isTranscriptShown){
			_this.showTranscriptPopup();
		}else{
			_this.hideTranscriptPopup();
		}
	}
		
	this.showTranscriptPopup = function(){
		_this.isTranscriptShown = true;
		_this.$transcriptContainer.show();	
	}
	
	this.hideTranscriptPopup = function(){
		_this.isTranscriptShown = false;
		_this.$transcriptContainer.hide();
		_this.$transcriptContainer.css({'left':'696px','top':'112px'});	
	}
	
	this.onTranscriptCloseBtnClick = function(){
		_this.hideTranscriptPopup();
	}
	
	this.setTranscriptContent = function(curText){
		_this.$transcriptContent.html(curText);	
		_this.$hiddenText.html(curText);
	}
	
	this.disableTranscriptBtn = function(){
		_this.$transcriptBtn.attr('disabled','disabled');	
	}
	
	this.enableTranscriptBtn = function(){
		_this.$transcriptBtn.removeAttr('disabled');	
	}
	
	this.enableTranscriptDrag = function(){
		var curCoords = {x:0,y:0};
		_this.$transcriptContainer.draggable({
			//containment : [0,0,1024,768],
			start:function(e,ui){
				/* curCoords.x = e.clientX;
				curCoords.y = e.clientY; */
				
				 ui.position.left = 0;
				 ui.position.top = 0;

				 containmentW = $("#container").width() * scale;
				 containmentH = $("#container").height() * scale;
				 objW = $(this).outerWidth() * scale;
				 objH = $(this).outerHeight() * scale;
			},
			drag:function(e,ui){
				
				$(this).css('z-index',100);
				
				var boundReached = false,

				changeLeft = ui.position.left - ui.originalPosition.left,
				newLeft = ui.originalPosition.left + changeLeft / scale,

				changeTop = ui.position.top - ui.originalPosition.top,
				newTop = ui.originalPosition.top + changeTop / scale;

				// right bound check
				if(ui.position.left > containmentW - objW) {
				  newLeft = (containmentW - objW) / scale;
				  boundReached = true;
				}

				// left bound check
				if(newLeft < 0) {
				  newLeft = 0;
				  boundReached = true;
				}

				// bottom bound check
				if(ui.position.top > containmentH - objH) {
				  newTop = (containmentH - objH) / scale;
				  boundReached = true;
				}

				// top bound check
				if(newTop < 0) {
				  newTop = 0;
				  boundReached = true;
				}

				// fix position
				ui.position.left = newLeft;
				ui.position.top = newTop;
								
			},
			stop : function(){
				$(this).css('z-index',1);				
			}
		});		
	}
	
	/**
		Audio Player
	*/
	
	this.createAudio = function(){
		_this.screenAudio = document.createElement('audio');
		_this.audioIntervalID = setInterval(_this.onAudioTimeUpdate,10);
	}
	
	
	this.playAudio = function(audioName){
		console.log(audioName);
		
		_this.curAudioName = audioName;
		
		if(!isIPAD && !isAndroid){
			_this.clearAudio();
			_this.curSoundJsInstance = createjs.Sound.play(audioName);
			_this.curSoundJsInstance.on('complete',_this.onAudioEnd);
			_this.curSoundJsInstance.muted = _this.isAudioMuted;
			console.log(_this.curSoundJsInstance);
			if (_this.curSoundJsInstance == null || _this.curSoundJsInstance.playState == createjs.Sound.PLAY_FAILED) {
				return;
			}
		}else{
			$(_this.screenAudio).attr('src',_this.commonAudioPath+audioName+".mp3");	
			$(_this.screenAudio)[0].load();
			$(_this.screenAudio)[0].play();
			$(_this.screenAudio).off('ended').on('ended',_this.onAudioEnd);
		}
		_this.$playBtn.removeClass(_this.playClass);
		_this.enablePlayBtn();
		_this.enableMuteBtn();
		//_this.$playBtn.removeClass(_this.pauseClass);
		//_this.$playBtn.addClass(_this.playClass);
		console.log( $(_this.screenAudio).attr('src') );
	}
	
	this.clearAudio = function(){
		if(!isIPAD && !isAndroid){
			createjs.Sound.stop();
		}else{
			$(_this.screenAudio)[0].pause();
			if( $(_this.screenAudio)[0].currentTime ){
				$(_this.screenAudio)[0].currentTime = 0;
			}			
			$(_this.screenAudio).attr('src','');
		}
	}
	
	
	this.onPlayBtnClick = function(){
		console.log(_this.curSoundJsInstance)
		
		if(!isIPAD && !isAndroid){
			var isAudioPaused = _this.curSoundJsInstance.paused;
		}else{
			var isAudioPaused = $(_this.screenAudio)[0].paused;	
		}
		
		if(isAudioPaused){
			if(!isIPAD && !isAndroid){
				_this.curSoundJsInstance.paused = false;
			}else{
				$(_this.screenAudio)[0].play();
			}
			
			_this.curScreenSpriteAnimation.paused = (_this.curScreenSpriteAnimation != '') ? false: true;
			//_this.$playBtn.removeClass(_this.pauseClass);
			_this.$playBtn.removeClass(_this.playClass);
			_this.$playBtn.attr('aria-label','Pause');
			_this.$hiddenText.html('Pause');
			//_this.$playBtn.html('Pause');
		}else{
			if(!isIPAD && !isAndroid){
				_this.curSoundJsInstance.paused = true;
			}else{
				$(_this.screenAudio)[0].pause();
			}
			_this.curScreenSpriteAnimation.paused = (_this.curScreenSpriteAnimation != '') ? true: false;
			//_this.$playBtn.addClass(_this.pauseClass);
			_this.$playBtn.addClass(_this.playClass);
			_this.$playBtn.attr('aria-label','Play');
			_this.$hiddenText.html('Play');
			//_this.$playBtn.html('Play');		
		}
	}
	
	this.disablePlayBtn = function(){
		_this.$playBtn.attr('disabled','disabled');		
	}
	
	this.enablePlayBtn = function(){
		_this.$playBtn.removeAttr('disabled');		
	}
	
	this.onMuteBtnClick = function(){
		if(!isIPAD && !isAndroid){
			var isMuted = _this.curSoundJsInstance.muted;
		}else{
			var isMuted = $(_this.screenAudio)[0].muted;
		}
		
		if(isMuted){
			if(!isIPAD && !isAndroid){
				_this.curSoundJsInstance.muted = false;	
				_this.isAudioMuted = false;
			}else{
				$(_this.screenAudio)[0].muted = false;
			}
			_this.$muteBtn.removeClass(_this.muteClass);
			_this.$muteBtn.addClass(_this.unMuteClass);
			_this.$muteBtn.attr('aria-label','Mute');
			_this.$hiddenText.html('Mute');
			//_this.$muteBtn.html('Mute');
		}else{
			if(!isIPAD && !isAndroid){
				_this.curSoundJsInstance.muted = true;
				_this.isAudioMuted = true;
			}else{
				$(_this.screenAudio)[0].muted = true;
			}
			_this.$muteBtn.removeClass(_this.unMuteClass);
			_this.$muteBtn.addClass(_this.muteClass);
			_this.$muteBtn.attr('aria-label','Unmute');
			_this.$hiddenText.html('Unmute');
			//_this.$muteBtn.html('UnMute');
		}
	}
	
	this.disableMuteBtn = function(){
		_this.$muteBtn.attr('disabled','disabled');		
	}
	
	this.enableMuteBtn = function(){
		_this.$muteBtn.removeAttr('disabled');		
	}
	
	this.onAudioTimeUpdate = function(){
		//console.log("Audio Update");
		
		if(!isIPAD && !isAndroid){
			var curAudioTime = _this.curSoundJsInstance.position / 1000;
		}else{
			var curAudioTime = $(_this.screenAudio)[0].currentTime;
		}
		
		if( curAudioTime ){
			//console.log( $(_this.screenAudio)[0].currentTime );
			
			if(curAudioTime > 0){
				_this.$contentContainer.show();
				_this.$preloader.hide();				
			}
			
			if(_this.curTemplateObj != ""){
				_this.curTemplateObj.onAudioTimeUpdate( curAudioTime );	
			}
		}
	}
	
	this.onAudioEnd = function(){
		console.log("Audio Ended");	
		
		if(_this.curTemplateObj != ""){
			_this.curTemplateObj.onAudioEnd(_this.curAudioName);	
		}
		
		_this.disablePlayBtn();
		_this.disableMuteBtn();
	}
	
	/**
		Navigation		
	*/
	
	this.onNextBtnClick = function(){
		if(_this.curScreenNo < _this.totalScreens){
			_this.curScreenNo++;
			_this.loadScreen();
		}
		console.log("Current Screen : "+_this.curScreenNo);
	}
	
	this.onPrevBtnClick = function(){
		if(_this.curScreenNo > 1){
			_this.curScreenNo--;
			_this.loadScreen();
		}
		console.log("Current Screen : "+_this.curScreenNo);
	}
	
	this.updateNavButtonStatus = function(){
		if(_this.curScreenNo == 1){
			_this.enableNextButton();
			_this.disablePreviousButton();
			console.log('FIRST SCREEN');
		}else if(_this.curScreenNo == _this.totalScreens){
			_this.disableNextButton();
			_this.enablePreviousButton();
			console.log('LAST SCREEN');
		}else{
			_this.enableNextButton();
			_this.enablePreviousButton();
		}
	}
	
	this.enableNextButton = function(){
		_this.$nextBtn.removeAttr('disabled');	
	}
	
	this.disableNextButton = function(){
		_this.$nextBtn.attr('disabled','disabled');			
	}
	
	this.enablePreviousButton = function(){
		_this.$prevBtn.removeAttr('disabled');
	}
	
	this.disablePreviousButton = function(){
		_this.$prevBtn.attr('disabled','disabled');		
		console.log(_this.$prevBtn);
	}
	
	/**
		Current Screen
	*/
	
	this.loadScreen = function(){
		console.log("Current Screen Loaded");	
		_this.updateNavButtonStatus();	
		_this.clearAudio();
		_this.$clickNext.hide();
		_this.$nextBtn.removeClass(_this.blinkClass);
		_this.disableNextBlink();
		_this.$contentContainer.hide();
		_this.$preloader.show();
		_this.onTranscriptCloseBtnClick();
		_this.isScreenLoadCompleted = false;
		
		(_this.curTemplateObj != "") ? _this.curTemplateObj.clear() : "";
		(_this.screenData[_this.curScreenNo-1].transcript != "") ? _this.enableTranscriptBtn() : _this.disableTranscriptBtn();	
		_this.setTranscriptContent(_this.screenData[_this.curScreenNo-1].transcript);
		//_this.$transcriptContent.html(_this.screenData[_this.curScreenNo-1].transcript);
		
		_this.$contentContainer.html('');
		_this.$contentContainer.load(_this.commonPagePath+_this.screenData[_this.curScreenNo-1].pageName+".html?version="+(new Date()).getTime(),_this.onPageLoadSuccess);
		
		console.log( _this.$transcriptContent );
	}
	
	
	this.onPageLoadSuccess = function(){
		console.log("PAGE LOAD COMPLETED: "+_this.screenData[_this.curScreenNo-1].jsonName);
		$.ajax({
			url:_this.commonDataPath+_this.screenData[_this.curScreenNo-1].jsonName+".json?version="+(new Date()).getTime(),
			dataType : "json",
			success:_this.onPageDataLoadSuccess
		});
		//_this.$contentContainer.load(_this.commonDataPath+_this.courseData[_this.curScreenNo-1].jsonName+".json",_this.onDataLoadSuccess);
	}
	
	
	this.onPageDataLoadSuccess = function(curData){
		console.log(curData);
		
		//_this.$contentContainer.show();
		//_this.$preloader.hide();
		
		if(_this.screenData[_this.curScreenNo-1].audio != ""){
			_this.enableMuteBtn();
			_this.enablePlayBtn();	
			_this.playAudio(_this.screenData[_this.curScreenNo-1].audio);
		}else{
			_this.disableMuteBtn();
			_this.disablePlayBtn();	
		}
	
		_this.isScreenLoadCompleted = true;
		
		var curTemplateName = _this.screenData[_this.curScreenNo-1].templateName;
		
		switch(curTemplateName){
			case "Screen1":
				_this.curTemplateObj = new Screen1(curData.data);
				_this.curTemplateObj.init(_this);
				break;
			case "Screen2":
				_this.curTemplateObj = new Screen2(curData.data);
				_this.curTemplateObj.init(_this);
				break;
			case "Screen3":
				_this.curTemplateObj = new Screen3(curData.data);
				_this.curTemplateObj.init(_this);
				break;
			case "Screen4":
				_this.curTemplateObj = new Screen4(curData.data);
				_this.curTemplateObj.init(_this);
				break;
			case "Screen6":
				_this.curTemplateObj = new Screen6(curData.data);
				_this.curTemplateObj.init(_this);
				break;
		}
		//_this.curTemplateObj = new window[ _this.screenData[_this.curScreenNo-1].templateName ](curData.data);
		//_this.curTemplateObj.init(_this);
	}
	
}