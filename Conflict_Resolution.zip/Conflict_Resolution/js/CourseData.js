var courseData = [
								{
									templateName : "Screen1",
									pageName : "Screen1",
									jsonName : "Screen1",
									audio : "slide_01",
									transcript : "Screen1 Transcript"
								},
								{
									templateName : "Screen2",
									pageName : "Screen2",
									jsonName : "Screen2",
									audio : "",
									transcript : ""								
								},
								{
									templateName : "Screen3",
									pageName : "Screen3",
									jsonName : "Screen3",
									audio : "slide_03",
									transcript : "Screen3 Transcript"								
								},
								{
									templateName : "Screen4",
									pageName : "Screen4",
									jsonName : "Screen4",
									audio : "slide_04",
									transcript : "Screen4 Transcript"								
								}
]