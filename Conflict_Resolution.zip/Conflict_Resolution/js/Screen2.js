var Screen2 = function(data){
	var currentScreenData = data;
	var templateObj; 
	
	this.init = function(_this){
		console.log("SCREEN2 INIT CALLED");
		console.log(currentScreenData);
		
		templateObj =  _this;
		
		$(".screenTitle").html(currentScreenData.screenTitle);
		$(".screenTitle,.screencontent").fadeIn();
		
		$(".spriteArea").html('<canvas width="251" height="544" id="stageCanvas"></canvas>').show();
		$("#pageTitle").html(currentScreenData.screenTitle);
		
		for(var i=0;i<currentScreenData.audioQuePoints.length;i++){
			var curClassName = currentScreenData.audioQuePoints[i].className;
			$("."+curClassName).hide();
		}
		
		this.initInstructor();
	}
	
	
	this.initInstructor = function(){
		animationStage = new createjs.Stage( $("#stageCanvas")[0] );	

		animationSpriteSheet = new createjs.SpriteSheet({
				"framerate" : 12,
				"images" : [
					"pages/images/screen1/avathar_character_and_animation_01_0.png",
					"pages/images/screen1/avathar_character_and_animation_01_1.png",
					"pages/images/screen1/avathar_character_and_animation_01_2.png",
					"pages/images/screen1/avathar_character_and_animation_01_3.png",
					"pages/images/screen1/avathar_character_and_animation_01_4.png",
					"pages/images/screen1/avathar_character_and_animation_01_5.png",
					"pages/images/screen1/avathar_character_and_animation_01_6.png"
				],
				"frames":{
					"regY": 0,
					"height": 544,
					"width": 251,
					"regX": 0,
					"count": 163
				},
				"animations": {
					"init" : [27,49,true],
					"step2" :[0,24,true],
					"step3" :[25,47,true],
					"step4" :[50,74,true],
					"step5" :[78,98,true]
				}
		});
		
		characterAnimation = new createjs.Sprite(animationSpriteSheet, "init");
		characterAnimation.x = 0;
		characterAnimation.y = 0;
		
		animationStage.addChild(characterAnimation);
		
		characterAnimation.gotoAndPlay("init");
		characterAnimation.visible = true;
		
		createjs.Ticker.removeEventListener("tick", animationStage);	
		//createjs.Ticker.removeEventListener("tick", characterTickHandler);	
		
		createjs.Ticker.addEventListener("tick", animationStage);	
		//createjs.Ticker.addEventListener("tick", characterTickHandler);	
		
		templateObj.curScreenSpriteAnimation = characterAnimation;
	}
	
	this.onAudioTimeUpdate = function(curTime){
		//console.log(curTime);

		for(var i=0;i<currentScreenData.audioQuePoints.length;i++){
			var startTime = currentScreenData.audioQuePoints[i].startTime;
			var endTime = currentScreenData.audioQuePoints[i].endTime;
			var isShown = currentScreenData.audioQuePoints[i].isShown;
			if( (startTime <= curTime) && (endTime >= curTime) && (isShown == "false") ){
				var curClassName = currentScreenData.audioQuePoints[i].className;
				var curType = currentScreenData.audioQuePoints[i].type;
				
				if(i == 0){
					characterAnimation.gotoAndPlay("step2");
				}else if(i == 5){
					characterAnimation.gotoAndPlay("step3");
				}else if(i == 7){
					characterAnimation.gotoAndPlay("step4");
				}else if(i == 8){
					characterAnimation.gotoAndPlay("step5");
				}
				
				if(curType == "fadeIn"){
					$("."+curClassName).fadeIn();
				}else if(curType == "fadeOut"){
					$("."+curClassName).fadeOut();
				}
				currentScreenData.audioQuePoints[i].isShown = true;
			}
		}
		
	}	
	
	this.onAudioEnd = function(){
		characterAnimation.gotoAndStop(89);
		$(".ScreenHint").fadeIn();
		templateObj.enableNextBlink();
		//$(".nextBtn").addClass(templateObj.blinkClass);
	}
		
	this.clear = function(){
		console.log("SCREEN2 CLEAR CALLED");
		
		templateObj.curScreenSpriteAnimation = '';
		
		createjs.Ticker.removeEventListener("tick", animationStage);	
		//createjs.Ticker.removeEventListener("tick", characterTickHandler);
	}
}