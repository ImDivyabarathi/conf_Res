var Screen4 = function(data){
	var currentScreenData = data;
	var templateObj; 
	var _this = this;
	var curClickedOptionIndex = 0;
	var curClickedOption = '';
	var isThomasKilmanCompleted = false;
	
	this.init = function(_templateObj){
		console.log("SCREEN4 INIT CALLED");
		console.log(currentScreenData);
		
		templateObj =  _templateObj;
		
		$(".screenTitle").html(currentScreenData.screenTitle);
		$(".screenTitle,.screencontent").fadeIn();
		
		$(".spriteArea").html('<canvas width="251" height="544" id="stageCanvas"></canvas>').show();
		
		console.log( $(".responseBox") );
		console.log( $(".thomasBox") );
		console.log( $(".strategyBox") );
		
		$(".responseBox").off('click').on('click',_this.onResponseBtnClick);
		$(".thomasBox").off('click').on('click',_this.onConflictBtnClick);
		$(".strategyBox").off('click').on('click',_this.onStrategyBtnClick);
		$(".backScenario").off('click').on('click',_this.onBackBtnClick);
		
		$(".screencontent_1").fadeIn();
		$(".screencontent_2").hide();
		$(".videoArea,.secondTab,.thirdTab").hide();
		$(".screenClick").css({'pointer-events':'none'}).attr('disabled','disabled');
		
		for(var i=0;i<currentScreenData.audioQuePoints.length;i++){
			var curClassName = currentScreenData.audioQuePoints[i].className;
			$("."+curClassName).hide();
		}
		
		_this.initInstructor();
		
		//templateObj.disableNextButton();
	}
	
	this.initInstructor = function(){
		animationStage = new createjs.Stage( $("#stageCanvas")[0] );	

		animationSpriteSheet = new createjs.SpriteSheet({
				"framerate" : 18,
				"images" : [
					"pages/images/screen1/avathar_character_and_animation_01_0.png",
					"pages/images/screen1/avathar_character_and_animation_01_1.png",
					"pages/images/screen1/avathar_character_and_animation_01_2.png",
					"pages/images/screen1/avathar_character_and_animation_01_3.png",
					"pages/images/screen1/avathar_character_and_animation_01_4.png",
					"pages/images/screen1/avathar_character_and_animation_01_5.png",
					"pages/images/screen1/avathar_character_and_animation_01_6.png"
				],
				"frames":{
					"regY": 0,
					"height": 544,
					"width": 251,
					"regX": 0,
					"count": 163
				},
				"animations": {
					"init" : [27,49,true],
					"step2" :[0,24,true],
					"step3" :[25,47,true],
					"step4" :[50,74,true],
					"step5" :[78,98,true]
				}
		});
		
		characterAnimation = new createjs.Sprite(animationSpriteSheet, "init");
		characterAnimation.x = 0;
		characterAnimation.y = 0;
		
		animationStage.addChild(characterAnimation);
		
		characterAnimation.gotoAndPlay(0);
		characterAnimation.visible = true;
		
		createjs.Ticker.removeEventListener("tick", animationStage);	
		//createjs.Ticker.removeEventListener("tick", characterTickHandler);	
		
		createjs.Ticker.addEventListener("tick", animationStage);	
		//createjs.Ticker.addEventListener("tick", characterTickHandler);	
		
		templateObj.curScreenSpriteAnimation = characterAnimation;
	}
	
	this.onAudioTimeUpdate = function(curTime){
		//console.log(curTime);
		
		for(var i=0;i<currentScreenData.audioQuePoints.length;i++){
			var startTime = currentScreenData.audioQuePoints[i].startTime;
			var endTime = currentScreenData.audioQuePoints[i].endTime;
			var isShown = currentScreenData.audioQuePoints[i].isShown;
			if( (startTime <= curTime) && (endTime >= curTime) && (isShown == "false") ){
				var curClassName = currentScreenData.audioQuePoints[i].className;
				currentScreenData.audioQuePoints[i].isShown = true;
				
				var curType = currentScreenData.audioQuePoints[i].type;
				
				if(i == 0){
					characterAnimation.gotoAndPlay("step2");
				}else if(i == 2){
					characterAnimation.gotoAndPlay("step3");
				}else if(i == 4){
					characterAnimation.gotoAndPlay("step4");
				}else if(i == 5){
					characterAnimation.gotoAndPlay("step5");
				}
				
				if(curType == "fadeIn"){
					$("."+curClassName).fadeIn();
				}else if(curType == "fadeOut"){
					$("."+curClassName).fadeOut();
				}
			}
		}
	}	
	
	this.onAudioEnd = function(audioName){
		characterAnimation.gotoAndStop(89);
		$(".screenClick").off('click').on('click',_this.onOptionClick).css('cursor','pointer');
		$(".screenClick").css({'pointer-events':'auto'}).removeAttr('disabled');
		
		if(audioName == "slide_04_2"){
			isThomasKilmanCompleted = true;
		}else if(audioName == "slide_04_8"){
			templateObj.enableNextButton();
			templateObj.enableNextBlink();
		}
	}
	
	this.onBackBtnClick = function(){
		$(".screencontent_2").hide();
		$(".screencontent_1").fadeIn();
		$(".videoArea,.secondTab,.thirdTab").hide();
		$(".responseBox,.thomasBox,.strategyBox").removeClass('active');
		$("."+currentScreenData.optionResponses[curClickedOptionIndex].strategy.highLightClass).css({'padding':'','border':''});
		
		_this.stopVideo();
		templateObj.clearAudio();
		characterAnimation.gotoAndStop(0);
		
		if( _this.isActivityCompleted() ){
			$(".row_6").html('You had viewed all the response and strategy. Now click Next to Continue.').fadeIn();
			templateObj.playAudio("slide_04_8");
		}
		
		templateObj.hideTranscriptPopup();
		templateObj.setTranscriptContent(templateObj.screenData[templateObj.curScreenNo-1].transcript);
		
		curClickedOption.focus();
	}
	
	this.onOptionClick = function(){
		var curIndex = $(this).index();
		console.log("curIndex: "+curIndex);
		
		curClickedOptionIndex = curIndex;
		
		if(isThomasKilmanCompleted){
			$(".thomasBox").hide();
			$(".strategyBox").css({'top':'121px'});
			$(".strategyBox span").html('2');
		}
		
		$(this).addClass('visited');
		$(".screencontent_1").fadeOut();
		$(".screencontent_2").fadeIn();
		$(".screenHint_1").hide().css({'left':'174px'});
		$(".responsePart .screenIntro").html(currentScreenData.optionResponses[curClickedOptionIndex].responseText);
				
		console.log( currentScreenData.optionResponses[curIndex] );
		
		currentScreenData.optionResponses[curClickedOptionIndex].isClicked = "true";
		
		templateObj.hideTranscriptPopup();
		templateObj.playAudio("slide_04_1"); // Play click each tab to know more audio
		
		templateObj.setTranscriptContent(currentScreenData.clickTabTranscript);
		
		curClickedOption = $(this);
	}
	
	this.stopVideo = function(){
		$(".videoArea video")[0].pause();
		if($(".videoArea video")[0].currentTime){
			$(".videoArea video")[0].currentTime = 0;
		}
		$(".videoArea video").attr('src','');
	}
	
	this.onVideoTimeUpdate = function(){
		if( $(".videoArea video")[0].currentTime > 0 ){
			$(".videoArea video").fadeIn();
			$(".videoArea .preloaderCon").fadeOut();
		}	
	}
	
	this.onResponseBtnClick = function(){
		console.log("onResponseBtnClick");
		
		characterAnimation.gotoAndStop(0);
		templateObj.disableMuteBtn();
		templateObj.disablePlayBtn();
		templateObj.clearAudio();
		
		$(".secondTab,.thirdTab").hide();
		$(".responseBox,.thomasBox,.strategyBox").removeClass('active');
		$(this).addClass('active');
		$(".videoArea video").hide();
		$(".videoArea .preloaderCon").show();
		$(".videoArea").fadeIn();	
		$(".screenHint_1").hide();
		$(".videoArea video").attr('src',currentScreenData.optionResponses[curClickedOptionIndex].response.videoPath);
		if(!isIPAD && !isAndroid){
			$(".videoArea video")[0].load();
			$(".videoArea video")[0].play(); //preloaderCon
		}else{
			$(".videoArea .preloaderCon").hide();
			//$(".videoArea video").show();
		}
		$(".videoArea video").off('timeupdate').on('timeupdate',_this.onVideoTimeUpdate);
		
		templateObj.setTranscriptContent(currentScreenData.optionResponses[curClickedOptionIndex].response.transcript);
	}
		
	this.onStrategyBtnClick = function(){
		console.log("onStrategyBtnClick");
		
		_this.stopVideo();
		
		$(".videoArea,.secondTab").hide().removeClass('active');
		$(".thirdTab").fadeIn();
		$(".responseBox,.thomasBox,.strategyBox").removeClass('active');
		$(this).addClass('active');
		
		$(".responsePart .screenIntro").html(currentScreenData.optionResponses[curClickedOptionIndex].responseText+" "+currentScreenData.optionResponses[curClickedOptionIndex].strategy.type);
		
		$(".thirdTabCallout").html(currentScreenData.optionResponses[curClickedOptionIndex].strategy.description);
		
		$("."+currentScreenData.optionResponses[curClickedOptionIndex].strategy.highLightClass).css({'padding':'5px','border':'4px solid yellow'});
		
		$(".screenHint_1").html(currentScreenData.optionResponses[curClickedOptionIndex].strategy.hintText).hide();
		
		currentScreenData.audioQuePoints = currentScreenData.optionResponses[curClickedOptionIndex].strategy.audioQuePoints;
		
		for(var i=0;i<currentScreenData.audioQuePoints.length;i++){
			currentScreenData.audioQuePoints[i].isShown = "false";
		}
		
		templateObj.playAudio(currentScreenData.optionResponses[curClickedOptionIndex].strategy.audio); 
		characterAnimation.gotoAndPlay(0);
		
		templateObj.setTranscriptContent(currentScreenData.optionResponses[curClickedOptionIndex].strategy.transcript);
	}
	
	this.onConflictBtnClick = function(){
		console.log("onConflictBtnClick");
		
		_this.stopVideo();
				
		$(".thirdTab,.videoArea").hide().removeClass('active');
		$(".secondTab").fadeIn();
		$(".responseBox,.thomasBox,.strategyBox").removeClass('active');
		$(this).addClass('active');
		$(".secondTab .flowChart_kilman,.secondTab .conflictImgArea,.secondTab .conflictText_1,.secondTab .conflictText_2,.secondTab .conflictText_3,.secondTab .conflictText_4,.secondTab .conflictText_5,.secondTab .kilmannText_1,.secondTab .kilmannText_2,.secondTab .flowChartText_1,.secondTab .flowchartArrow,.secondTab .flowChartText_2,.secondTab .flowChartText_3").hide();
		$(".flowChartText").show();
		
		$(".screenHint_1").html(currentScreenData.optionResponses[curClickedOptionIndex].conflictModel.hintText).hide();
		
		currentScreenData.audioQuePoints = currentScreenData.optionResponses[curClickedOptionIndex].conflictModel.audioQuePoints;
		
		for(var i=0;i<currentScreenData.audioQuePoints.length;i++){
			currentScreenData.audioQuePoints[i].isShown = "false";		
		}
		
		templateObj.playAudio("slide_04_2"); 
		characterAnimation.gotoAndPlay(0);
		
		templateObj.setTranscriptContent(currentScreenData.optionResponses[curClickedOptionIndex].conflictModel.transcript);
	}
	
	this.isActivityCompleted = function(){
		var completedCount = 0;
		for(var i=0;i<currentScreenData.optionResponses.length;i++){
			if(currentScreenData.optionResponses[i].isClicked == "true"){
				completedCount++;
			}
		}
		
		console.log(completedCount+" "+currentScreenData.optionResponses.length);
		
		if(completedCount == currentScreenData.optionResponses.length){
			return true;		
		}else{
			return false;
		}
	}
		
	this.clear = function(){
		console.log("SCREEN5 CLEAR CALLED");
		
		templateObj.curScreenSpriteAnimation = '';
		
		createjs.Ticker.removeEventListener("tick", animationStage);
		
		$(".videoArea video").off('timeupdate',_this.onVideoTimeUpdate);
	}
}